function aler() {
    window.alert("This is alert box")
}

function confir(){
    window.confirm("This is confirm box")
}