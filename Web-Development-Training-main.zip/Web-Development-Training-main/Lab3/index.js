// function test(x,y=20){
//     return x+y;
// }
// let t=test(5)
// console.log(t)


// let t=function(){
//     console.log("Anonymous Function")
// }
// t()


// let t = () =>{
//     console.log("Arrow Function")
// }
// t()





// function test(){
//     console.log("Function")
// }
// test()




// function test(x,y) {
//     return x+y
// }
// console.log(test(20,30))



// function test(x=10,y) {
//     return x+y

// }

// console.log(test(5))