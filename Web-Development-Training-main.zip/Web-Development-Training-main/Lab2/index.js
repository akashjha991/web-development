// console.log("5"+2+3)
// console.log(2+3+"5")

// console.log("5"==5)
// console.log("5"===5)

// console.log(5+2+"5"+2+6)

// console.log(5!="5")
// console.log("5"!==5)


function XYZ() {
    console.log("AAsoy8ijas")
}

XYZ()